<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::insert('insert into posts (title, body, author, created_at) values (?, ?, ?, ?)', ['Title N-', 'Lorem ipsum', 'Shukri Mamatsashvili\'s Clone '.$count, date('d-m-y h:i:s', time())]);
        DB::table('posts') -> insert(['title'=>Str::random(20), 'body' =>Str::random(100), 'author'=>Str::random(15), 'created_at' => date('y-m-d h:i:s', time()), 'active' => 1]);
    }
}
