<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>ERROR PAGE</title>

</head>
<body  style="font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif">
    <h1 style="text-align: center;">ERROR PAGE</h1>
    
</body>   
</html><?php /**PATH C:\Users\mamat\Desktop\Laravel\example\resources\views/welcome.blade.php ENDPATH**/ ?>